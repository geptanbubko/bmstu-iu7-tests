"""Точка сборки: UI + бизнес-логика + доступ к данным + конфиг + логи."""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from wildlife_app.config import AppConfig, default_config_path, load_config
from wildlife_app.logging_setup import setup_logging
from wildlife_business.analytics_service import AnalyticsService
from wildlife_business.catalog_service import CatalogService
from wildlife_business.observation_service import ObservationService
from wildlife_data.sqlite_repository import SqliteRepository
from wildlife_ui.console_app import ConsoleApp
from wildlife_ui.io import ConsoleIO, IUserIO

logger = logging.getLogger("wildlife.app")


def build_app(
    database: str | Path,
    io: IUserIO | None = None,
    min_records_for_trend: int = 5,
) -> tuple[ConsoleApp, SqliteRepository]:
    repo = SqliteRepository(database)
    app = ConsoleApp(
        ObservationService(repo),
        CatalogService(repo),
        AnalyticsService(repo, min_records_for_trend=min_records_for_trend),
        io or ConsoleIO(),
    )
    return app, repo


def run_with_config(config: AppConfig, io: IUserIO | None = None) -> None:
    setup_logging(config.log_file, config.log_level)
    logger.info(
        "Приложение запущено: db=%s trend=%s log=%s",
        config.database_path,
        config.min_records_for_trend,
        config.log_file,
    )
    app, repo = build_app(
        config.database_path,
        io=io,
        min_records_for_trend=config.min_records_for_trend,
    )
    try:
        app.run()
    except Exception:
        logger.exception("Фатальная ошибка приложения")
        raise
    finally:
        repo.close()
        logger.info("Приложение остановлено")


def main(argv: list[str] | None = None) -> None:
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description="Wildlife Monitoring — технологический UI")
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Путь к config.ini",
    )
    args = parser.parse_args(argv)
    config_path = args.config or default_config_path()
    config = load_config(config_path)
    run_with_config(config)


if __name__ == "__main__":
    main()
